#ifndef FUNCTIONS_INCLUDED
#define FUNCTIONS_INCLUDED

#include <stdio.h>
#include <cstdlib.h>
#intlcude "rand.h"

struct LSHFunction
{
	float* a;				// random vector a
	float  b;				// random variable b
	float  W;				// width of the function
}

typedef LSHFunction* LSHFunctionPtr;





#endif