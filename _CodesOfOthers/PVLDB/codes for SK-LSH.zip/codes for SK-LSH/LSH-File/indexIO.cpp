/*---------------------------------------------------------------

- This file is created to implement the functions defined in 
- indexIO.h.

- By Michael Liu -

- 2013-04-02 -

---------------------------------------------------------------*/


#include <direct.h>
#include <string.h>
#include "indexIO.h"


// ------ the writer operation ------ //
/*----------------------------------------------------

- This function is created to write the Index File
- to the specified folder.
- The contents written contain :
- 1. the basic parameters such as n, d, L, M, B
- 2. the LSH functons
- 3. the parameters related to the index, espcially
     num_first, num_second, items_per_page
- 4. the second index
- 5. the first index for each file
- 6. the the sorted points

----------------------------------------------------*/
/**/
void writeIndexToFiles(char* destFolder,IndexFilePtr idxfl)
{
	// check the existence of the folder
	if ( -1 == chdir(destFolder))
	{
		printf("Fail to find the folder %s. Please check!!\n", destFolder);

		system("pause");
		exit(-1);
	}

	char filename[100];
	char para[40]			= "para";
	char secondidx[40]		= "secondidx";
	char firstidx[40]		= ".index";
	FILE* fp				= NULL;

	int i					= -1;
	int j					= -1;
	int k					= -1;

	// ------ write the parameters and lsh functions into the file ------
	// obtain the responding filename
	strcpy(filename, destFolder);
	strcat(filename, "\\");
	strcat(filename, para);

	fp = fopen(filename, "wb");

	if (NULL == fp)
	{
		printf("Fail to open %s.\n", filename);
		system("pause");
		exit(-1);
	}

	// basic parameters
	fwrite(&idxfl->n, sizeof(int), 1, fp);
	fwrite(&idxfl->d, sizeof(int), 1, fp);
	fwrite(&idxfl->L, sizeof(int), 1, fp);
	fwrite(&idxfl->M, sizeof(int), 1, fp);
	fwrite(&idxfl->B, sizeof(int), 1, fp);	

	// write the lsh functions into the para file
	//int count = -1;
	fwrite(idxfl->a_array, sizeof(float), idxfl->L*idxfl->M*idxfl->d, fp);
	//count = fwrite(idxfl->a_array, sizeof(float), idxfl->L*idxfl->M*idxfl->d, fp);
	//printf("count = %d\n", count);
	fwrite(idxfl->b_array, sizeof(float), idxfl->L*idxfl->M, fp);
	//count = fwrite(idxfl->b_array, sizeof(float), idxfl->L*idxfl->M, fp);
	//printf("count = %d\n", count);
	//fwrite(&idxfl->W, sizeof(float), 1, fp);
	fwrite(idxfl->w_array, sizeof(float), idxfl->M, fp);

	//for (i=0;i<idxfl->M;i++)
	//{
	//	printf("%f\t", idxfl->w_array[i]);
	//}
	//printf("\n");

	// parameters related to index files
	fwrite(&idxfl->num_first, sizeof(int), 1, fp);
	fwrite(&idxfl->num_second, sizeof(int), 1, fp);
	fwrite(&idxfl->items_per_page, sizeof(int), 1, fp);

	fclose(fp);


	// ------ write the second index to the corresponding file ------
	// obtain the filename
	strcpy(filename, destFolder);
	strcat(filename, "\\");
	strcat(filename, secondidx);

	fp = fopen(filename, "wb");

	if (NULL == fp)
	{
		printf("Fail to open %s.\n", filename);
		system("pause");
		exit(-1);
	}

	for (i=0;i<idxfl->L;i++)
	{
		for (j=0;j<idxfl->num_second;j++)
		{
			fwrite(&idxfl->secondIndex[i][j].ID, sizeof(int), 1, fp);
			fwrite(&idxfl->secondIndex[i][j].num, sizeof(int), 1, fp);

			fwrite(idxfl->secondIndex[i][j].begin, sizeof(int), idxfl->M, fp);
			fwrite(idxfl->secondIndex[i][j].end, sizeof(int), idxfl->M, fp);
		}
	}

	fclose(fp);


	// ------ write the first index to the corrsponding file ------
	char	num_str[40];
	float*	pf = NULL;
	float	fv = 0.0;
	
	for (i=0;i<idxfl->L;i++)
	{
		// obtain the file name
		strcpy(filename, destFolder);
		strcat(filename, "\\");
		itoa(i, num_str, 10);
		strcat(filename, num_str);
		strcat(filename, firstidx);

		fp = fopen(filename, "wb");

		if (NULL == fp)
		{
			printf("Fail to oper %s.\n", filename);

			system("pause");
			exit(-1);
		}

		// write the first index to the file
		for (j=0;j<idxfl->num_first;j++)
		{
			fwrite(&idxfl->firstIndex[i][j].ID, sizeof(int), 1, fp);
			fwrite(&idxfl->firstIndex[i][j].num, sizeof(int), 1, fp);

			fwrite(idxfl->firstIndex[i][j].begin, sizeof(int), idxfl->M, fp);
			fwrite(idxfl->firstIndex[i][j].end, sizeof(int), idxfl->M, fp);
		}

		// write the data set to the file
		for (j=0;j<idxfl->n;j++)
		{
			// write the id of the point
			k  = idxfl->orderList[i][j];
			fv = (float) k;
			fwrite(&fv, sizeof(float), 1, fp);

			// acquire the pointer referring to the starting place of the jth point
			pf = idxfl->ds.pointArray + k*idxfl->d;
			fwrite(pf, sizeof(float), idxfl->d, fp);
			pf = NULL;
		}

		fclose(fp);
	}
}


                                                          



// ------ the read operation ------ //
/*---------------------------------------------------------

- This function is implemented for the purpose of checking
- whether the index files are correctly written during 
- the produre of the 'write' operation.

---------------------------------------------------------*/

/*
void readIndexFromFiles(char* sourceFolder, IndexFilePtr)
{
	// check the existence of the specified folder
	if ( -1 == chdir(sourceFolder))
	{
		printf("Fail to find the folder %s. Please check!!\n", sourceFolder);

		system("pause");
		exit(-1);
	}

	char filename[100];
	char para[40]			= "para";
	char secondidx[40]		= "secondidx";
	char firstidx[40]		= ".index";
	FILE* fp				= NULL;


}
*/

