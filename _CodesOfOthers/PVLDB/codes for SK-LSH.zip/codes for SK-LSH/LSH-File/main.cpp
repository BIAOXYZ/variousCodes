/*-----------------------------------------------------------------

// -This file is created to show an example how to use the codes to perform knn queries
// -for a set of query points
// By Yingfan Liu on 2014-03-11

-----------------------------------------------------------------*/


#include <direct.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <conio.h>
#include <windows.h>

#include "BasicOperations.h"
#include "construction.h"
#include "heap.h"
#include "search.h"
#include "linearScan.h"


/**/
int main()
{
	//---parameters---

	// parameters related to the data set
	int		n					= 67990;		// the size of the data set
	int		d					= 32;			// the dimensionality of the data set
	char	dsfile[100]			= "E:\\WORKING\\LSH-File\\Color\\colorD.txt";		// file name of the data set

	// parameters related to the query set
	int		nq					= 50;			// size of the query set
	char    queryfile[100]		= "E:\\WORKING\\LSH-File\\Color\\colorQ.txt";		// file name of the query set
	float*  query		= (float*)	malloc(sizeof(float)*d);						// the query point

	// parameters related to the index file
	int		L					= 3;			// number of hash structures
	int		M					= 12;			// number of LSH functions in a compound LSH function
	float	Wb					= 0.8;			// the width for a single LSH function
	float	Wr					= 1;			// this variable is fixed as 1 currently
	int		B					= 100;			// size of a disk page that indicates that a disk page could hold 100 points at most
												// this variable is fixed as 100 currently
	char	indexfolder[100]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";		// file name of index files

	// parameters related to the search process	
	int		nk					= 100;			// number of returned neighbors
	int		npage				= 10;			// number of pages accessed during the search process
	

	// parameters related to performance statistics 
	clock_t start, end;
	int		time_count			= 0;
	double	ratio				= 0;
	double	duration			= 0;
	double	np					= 0;

	REheap rh1, rh2;
	rh1.initialize(nk);
	rh2.initialize(nk);

	int		i					= 0;
	int		j					= 0;
	int		k					= 0;
	

	
	//---operations---

	// get the data set and the query set
	DataSet ods, qds;
	ods.getParameters(n, d);
	ods.readDataSetFromFile(dsfile);
	qds.getParameters(nq, d);
	qds.readDataSetFromFile(queryfile);

	// initialize the index file
	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, Wb, Wr, dsfile);

	// build index files
	i_file.buildIndex(indexfolder);

	// initialize the search class
	SearchClass sc;
	sc.initialize(indexfolder);

	for (i=0;i<nq;i++)
	{
		// get the query point
		for (j=0;j<d;j++)
		{
			query[j] = qds.pointArray[i*d+j];
		}

		start = clock();
		sc.search(query, nk, npage, &rh1);
		end   = clock();
		time_count += end - start;

		getExactNearestNeighbors(query, &ods, nk, & rh2);
				
		ratio += compareResult(rh1, rh2);
		np    += (double)sc.npoint_marked;
			
	}

	printf("Time cost for each query on average is %f ms.\n", double(time_count) / CLOCKS_PER_SEC / nq * 1000);
	printf("ratio is %f.\n", ratio / nq);
	printf("%f pionts are verified on average.\n", np /nq);

	free(query);

	system("pause");
	return 0;
}


/*
int main()
{
	//---parameters---

	// parameters related to the data set
	int		n					= 275415;		// the size of the data set
	int		d					= 60;			// the dimensionality of the data set
	char	dsfile[100]			= "E:\\WORKING\\LSH-File\\Aerial\\data.txt";		// file name of the data set

	// parameters related to the query set
	int		nq					= 50;			// size of the query set
	char    queryfile[100]		= "E:\\WORKING\\LSH-File\\Aerial\\query.txt";		// file name of the query set
	float*  query		= (float*)	malloc(sizeof(float)*d);						// the query point

	// parameters related to the index file
	int		L					= 3;			// number of hash structures
	int		M					= 30;			// number of LSH functions in a compound LSH function
	float	Wb					= 40;			// the width for a single LSH function
	float	Wr					= 1;			// this variable is fixed as 1 currently
	int		B					= 100;			// size of a disk page that indicates that a disk page could hold 100 points at most
												// this variable is fixed as 100 currently
	char	indexfolder[100]	= "E:\\WORKING\\LSH-File\\Aerial\\HashTables";		// file name of index files

	// parameters related to the search process	
	int		nk					= 100;			// number of returned neighbors
	int		npage				= 10;			// number of pages accessed during the search process
	

	// parameters related to performance statistics 
	clock_t start, end;
	int		time_count			= 0;
	double	ratio				= 0;
	double	duration			= 0;
	double	np					= 0;

	REheap rh1, rh2;
	rh1.initialize(nk);
	rh2.initialize(nk);

	int		i					= 0;
	int		j					= 0;
	int		k					= 0;
	

	
	//---operations---

	// get the data set and the query set
	DataSet ods, qds;
	ods.getParameters(n, d);
	ods.readDataSetFromFile(dsfile);
	qds.getParameters(nq, d);
	qds.readDataSetFromFile(queryfile);

	// initialize the index file
	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, Wb, Wr, dsfile);

	// build index files
	i_file.buildIndex(indexfolder);

	// initialize the search class
	SearchClass sc;
	sc.initialize(indexfolder);

	for (i=0;i<nq;i++)
	{
		// get the query point
		for (j=0;j<d;j++)
		{
			query[j] = qds.pointArray[i*d+j];
		}

		start = clock();
		sc.search(query, nk, npage, &rh1);
		end   = clock();
		time_count += end - start;

		getExactNearestNeighbors(query, &ods, nk, & rh2);
				
		ratio += compareResult(rh1, rh2);
		np    += (double)sc.npoint_marked;
			
	}

	printf("Time cost for each query on average is %f ms.\n", double(time_count) / CLOCKS_PER_SEC / nq * 1000);
	printf("ratio is %f.\n", ratio / nq);
	printf("%f pionts are verified on average.\n", np /nq);

	free(query);

	system("pause");
	return 0;
}
*/

/*
int main()
{
	//---parameters---

	// parameters related to the data set
	int		n					= 54337;		// the size of the data set
	int		d					= 192;			// the dimensionality of the data set
	char	dsfile[100]			= "E:\\WORKING\\LSH-File\\Audio\\data.txt";		// file name of the data set

	// parameters related to the query set
	int		nq					= 50;			// size of the query set
	char    queryfile[100]		= "E:\\WORKING\\LSH-File\\Audio\\query.txt";		// file name of the query set
	float*  query		= (float*)	malloc(sizeof(float)*d);						// the query point

	// parameters related to the index file
	int		L					= 3;			// number of hash structures
	int		M					= 30;			// number of LSH functions in a compound LSH function
	float	Wb					= 3;			// the width for a single LSH function
	float	Wr					= 1;			// this variable is fixed as 1 currently
	int		B					= 100;			// size of a disk page that indicates that a disk page could hold 100 points at most
												// this variable is fixed as 100 currently
	char	indexfolder[100]	= "E:\\WORKING\\LSH-File\\Audio\\HashTables";		// file name of index files

	// parameters related to the search process	
	int		nk					= 100;			// number of returned neighbors
	int		npage				= 10;			// number of pages accessed during the search process
	

	// parameters related to performance statistics 
	clock_t start, end;
	int		time_count			= 0;
	double	ratio				= 0;
	double	duration			= 0;
	double	np					= 0;

	REheap rh1, rh2;
	rh1.initialize(nk);
	rh2.initialize(nk);

	int		i					= 0;
	int		j					= 0;
	int		k					= 0;
	

	
	//---operations---

	// get the data set and the query set
	DataSet ods, qds;
	ods.getParameters(n, d);
	ods.readDataSetFromFile(dsfile);
	qds.getParameters(nq, d);
	qds.readDataSetFromFile(queryfile);

	// initialize the index file
	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, Wb, Wr, dsfile);

	// build index files
	i_file.buildIndex(indexfolder);

	// initialize the search class
	SearchClass sc;
	sc.initialize(indexfolder);

	for (i=0;i<nq;i++)
	{
		// get the query point
		for (j=0;j<d;j++)
		{
			query[j] = qds.pointArray[i*d+j];
		}

		start = clock();
		sc.search(query, nk, npage, &rh1);
		end   = clock();
		time_count += end - start;

		getExactNearestNeighbors(query, &ods, nk, & rh2);
				
		ratio += compareResult(rh1, rh2);
		np    += (double)sc.npoint_marked;
			
	}

	printf("Time cost for each query on average is %f ms.\n", double(time_count) / CLOCKS_PER_SEC / nq * 1000);
	printf("ratio is %f.\n", ratio / nq);
	printf("%f pionts are verified on average.\n", np /nq);

	free(query);

	system("pause");
	return 0;
}
*/

/*
int main()
{
	//---parameters---

	// parameters related to the data set
	int		n					= 1000000;		// the size of the data set
	int		d					= 128;			// the dimensionality of the data set
	char	dsfile[100]			= "E:\\WORKING\\LSH-File\\SIFT\\data.txt";		// file name of the data set

	// parameters related to the query set
	int		nq					= 50;			// size of the query set
	char    queryfile[100]		= "E:\\WORKING\\LSH-File\\SIFT\\query.txt";		// file name of the query set
	float*  query		= (float*)	malloc(sizeof(float)*d);						// the query point

	// parameters related to the index file
	int		L					= 3;			// number of hash structures
	int		M					= 30;			// number of LSH functions in a compound LSH function
	float	Wb					= 1000;			// the width for a single LSH function
	float	Wr					= 1;			// this variable is fixed as 1 currently
	int		B					= 100;			// size of a disk page that indicates that a disk page could hold 100 points at most
												// this variable is fixed as 100 currently
	char	indexfolder[100]	= "E:\\WORKING\\LSH-File\\SIFT\\HashTables";		// file name of index files

	// parameters related to the search process	
	int		nk					= 100;			// number of returned neighbors
	int		npage				= 10;			// number of pages accessed during the search process
	

	// parameters related to performance statistics 
	clock_t start, end;
	int		time_count			= 0;
	double	ratio				= 0;
	double	duration			= 0;
	double	np					= 0;

	REheap rh1, rh2;
	rh1.initialize(nk);
	rh2.initialize(nk);

	int		i					= 0;
	int		j					= 0;
	int		k					= 0;
	

	
	//---operations---

	// get the data set and the query set
	DataSet ods, qds;
	ods.getParameters(n, d);
	ods.readDataSetFromFile(dsfile);
	qds.getParameters(nq, d);
	qds.readDataSetFromFile(queryfile);

	// initialize the index file
	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, Wb, Wr, dsfile);

	// build index files
	i_file.buildIndex(indexfolder);

	// initialize the search class
	SearchClass sc;
	sc.initialize(indexfolder);

	for (i=0;i<nq;i++)
	{
		// get the query point
		for (j=0;j<d;j++)
		{
			query[j] = qds.pointArray[i*d+j];
		}

		start = clock();
		sc.search(query, nk, npage, &rh1);
		end   = clock();
		time_count += end - start;

		getExactNearestNeighbors(query, &ods, nk, & rh2);
				
		ratio += compareResult(rh1, rh2);
		np    += (double)sc.npoint_marked;
			
	}

	printf("Time cost for each query on average is %f ms.\n", double(time_count) / CLOCKS_PER_SEC / nq * 1000);
	printf("ratio is %f.\n", ratio / nq);
	printf("%f pionts are verified on average.\n", np /nq);

	free(query);

	system("pause");
	return 0;
}
*/