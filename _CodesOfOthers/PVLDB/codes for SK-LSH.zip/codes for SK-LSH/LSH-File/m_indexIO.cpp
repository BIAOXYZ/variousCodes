/*-------------------------------------------------------------

- This file is created to test the functions defined in 
- indexIO.h.

- By Michael Liu -

- 2013-04-02 -

-------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <direct.h>
#include <string.h>
#include "indexIO.h"

/*
int main()
{
	char foldername[40] = "Liu\\Ying\\Fan";  //E:\\WORKING\\LSH-File\\

	char filename[40]; 

	char str[100];

	strcpy(filename,foldername);

	printf("%s\n",filename);

	strcat(filename,"\\1.txt");

	printf("%s\n",filename);

	//FILE* fp = fopen(foldername,"w");

	//if (NULL == fp)
	//{
	//	printf("Fail to open the specific folder.\n");
	//}

	//if ( -1 == chdir(foldername))
	//{
	//	printf("Fail to open the specific folder.\n");
	//}

	//fclose(fp);

	FILE* fp = fopen(filename,"r");

	fscanf(fp,"%s",str);

	printf("%s\n",str);

	system("pause");
	return 0;
}
*/


/*
int main()
{
	int i = 144455;
	int j = 30;

	char str[40];

	itoa(i,str,10);
	printf("%s\n",str);

	itoa(j,str,10);
	printf("%s\n",str);

	//char a[40] = "Liu Ying Fan";
	//char b[40] = "Liu";
	//strcpy(a,b);
	//printf("%s\n",a);


	system("pause");
	return 0;
	
}
*/


/*
int main()
{
	int	 num	= 10;
	int	 i		= -1;
	int* pi		= (int*) malloc(sizeof(int)*num);
	int* pt		= NULL;

	for (i=0;i<num;i++)
	{
		pi[i] = i;
	}

	pt = pi + 5;
	printf("%d\n", *pt);

	system("pause");
	return 0;
}
*/


/*
int main()
{
	char	filename[40]  = "test.txt";
	int		i			  = 4;
	float	f1			  = 0.0;
	float	f2			  = 0.0;
	FILE*	fp			  = fopen(filename, "w");

	f1 = (float) i;
	fwrite(&f1, sizeof(float), 1, fp);

	fclose(fp);

	fp = fopen(filename, "r");

	fread(&f2, sizeof(float), 1, fp);

	printf("%d\n",(int)f2);

	fclose(fp);

	system("pause");
	return 0;
}
*/


/*
int main()
{
	int		n				= 67990;
	int		d				= 32;
	int		L				= 4;
	int		M				= 10;
	int		B				= 100;
	float	Wb				= 0.2;
	float	Wr				= 1.5;
	char	filename[40]	= "../Color/colorD.txt";

	char	destFolder[40]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";

	// ---------- ���������ṹ ---------- //

	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, Wb, Wr, filename);
	i_file.generateLSHFunctions();
	i_file.getHashKeys();
	i_file.sortHashKeys();
	i_file.buildIndex();

	// ---------- �������ṹд���ļ� ---------- //

	writeIndexToFiles(destFolder, &i_file);

	// ---------- ��д��ȥ���ļ�һһ��������У�����Ƿ����� ---------- //

	char	fn[100];
	char	para[40]			= "para";
	char	secondidx[40]		= "secondidx";
	char	firstidx[40]		= ".index";
	char	sourceFolder[40]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";
	FILE*	fp					= NULL;

	int		i					= -1;
	int		j					= -1;
	int		k					= -1;

	int		vi					= -1;
	float	vf					= 0.0;

	
	strcpy(fn, sourceFolder);
	strcat(fn, "\\");
	strcat(fn, para);

	fp = fopen(fn, "rb");

	if (NULL == fp)
	{
		printf("Fail to open %s.\n", fn);

		system("pause");
		return -1;
	}

	// ��ȡ�����Ĳ���
	fread(&vi, sizeof(int), 1, fp);
	printf("n = %d\n", vi);
	fread(&vi, sizeof(int), 1, fp);
	printf("d = %d\n", vi);
	fread(&vi, sizeof(int), 1, fp);
	printf("L = %d\n", vi);
	fread(&vi, sizeof(int), 1, fp);
	printf("M = %d\n", vi);
	fread(&vi, sizeof(int), 1, fp);
	printf("B = %d\n", vi);

	// �������
	//for (i=0;i<i_file.L;i++)
	//{
	//	printf("i = %d\n", i);
	//	for (j=0;j<i_file.M;j++)
	//	{
	//		printf("j = %d\n", i);
	//		for (k=0;k<i_file.d;k++)
	//		{
	//			fread(&vf, sizeof(float), 1, fp);
	//			printf("%f\t", vf);
	//		}
	//		printf("\n");
	//	}
		
	//}

	// ��ȡLSH����, ����ԭ�ȵĽ��бȽ�
	float* a_array = (float*) malloc(sizeof(float)*i_file.L*i_file.M*i_file.d);
	float* b_array = (float*) malloc(sizeof(float)*i_file.L*i_file.M);
	float* w_array = (float*) malloc(sizeof(float)*i_file.M);

	printf("L*M*d = %d\n", i_file.L*i_file.M*i_file.d);

	int count = -1;
	count = fread(a_array, sizeof(float), i_file.L*i_file.M*i_file.d, fp);
	printf("count = %d\n", count);

	if (feof(fp))
	{
		printf("the file is over.\n");
	}
	
	count = fread(b_array, sizeof(float), i_file.L*i_file.M, fp);
	printf("count = %d\n", count);
	count = fread(w_array, sizeof(float), i_file.M, fp);
	printf("count = %d\n", count);
	
	for (i=0;i<i_file.L;i++)
	{
		printf("Information for Table %d.\n", i);

		for (j=0;j<i_file.M;j++)
		{
			printf("The %d-th LSH function\n", j);
			for (k=0;k<i_file.d;k++)
			{
				printf("%f", a_array[i*i_file.M*i_file.d+j*i_file.d+k]);
				printf("(");
				printf("%f", i_file.a_array[i*i_file.M*i_file.d+j*i_file.d+k]);
				printf(")\t");
			}

			printf("\n%f(%f)\n", b_array[i*i_file.M+j], i_file.b_array[i*i_file.M+j]);
		}
	}
	
	printf("Information for Widths.\n");
	for (i=0;i<i_file.M;i++)
	{
		printf("%f(%f)\t", w_array[i], i_file.w_array[i]);
	}
	printf("\n");

	fread(&vi, sizeof(int), 1, fp);
	printf("num_first = %d(%d)\n", vi, i_file.num_first);
	fread(&vi, sizeof(int), 1, fp);
	printf("num_second = %d(%d)\n", vi, i_file.num_second);
	fread(&vi, sizeof(int), 1, fp);
	printf("items_per_page = %d(%d)\n", vi, i_file.items_per_page);

	free(a_array);
	free(b_array);
	fclose(fp);

	system("pause");
	return 0;
}
*/


/*
int main()
{
	char filename[40] = "test.t";
	int i = -1;
	int count = -1;
	int a[10000];

	for (i=0;i<10000;i++)
	{
		a[i] = i;
	}

	FILE* fp = fopen(filename, "wb");

	count = fwrite(a, sizeof(int), 10000, fp);

	printf("count = %d\n", count);

	fclose(fp);

	int* pi = (int*) malloc(sizeof(int)*10000);

	fp = fopen(filename, "rb");

	if (feof(fp))
		printf("it is over.\n");

	count = fread(pi, sizeof(int), 10000, fp);
	printf("count = %d\n", count);

	//count = fread(pi, sizeof(int), 100, fp);
	//printf("count = %d\n", count);

	for (i=0;i<10000;i++)
	{
		printf("%d\t", pi[i]);
	}
	printf("\n");

	fclose(fp);

	system("pause");
	return 0;

}

*/


/*
// check the second index
int main()
{
	int		n				= 50;
	int		d				= 32;
	int		L				= 4;
	int		M				= 4;
	int		B				= 2;
	float	W				= 0.2;
	char	filename[40]	= "../Color/colorQ.txt";

	char	destFolder[40]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";

	// ---------- ���������ṹ ---------- //

	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, W, filename);
	i_file.generateLSHFunctions();
	i_file.getHashKeys();
	i_file.sortHashKeys();
	i_file.buildIndex();

	// ---------- �������ṹд���ļ� ---------- //

	writeIndexToFiles(destFolder, &i_file);

	// ---------- ��д��ȥ���ļ�һһ��������У�����Ƿ����� ---------- //

	char	fn[100];
	char	para[40]			= "para";
	char	secondidx[40]		= "secondidx";
	char	firstidx[40]		= ".index";
	char	sourceFolder[40]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";
	FILE*	fp					= NULL;

	int		i					= -1;
	int		j					= -1;
	int		k					= -1;

	int		vi					= -1;
	float	vf					= 0.0;

	
	strcpy(fn, sourceFolder);
	strcat(fn, "\\");
	strcat(fn, secondidx);

	fp = fopen(fn, "rb");

	if (NULL == fp)
	{
		printf("Fail to open %s.\n", fn);

		system("pause");
		return -1;
	}

	// ���ζ���ÿ��page item
	int* pi = (int*) malloc(sizeof(int)*i_file.M);

	for (i=0;i<i_file.L;i++)
	{
		printf("Information for Table %d\n", i);

		for (j=0;j<i_file.num_second;j++)
		{
			printf("%d-th item:\n", j);

			fread(&vi, sizeof(int), 1, fp);
			printf("ID: %d(%d)\n", vi, i_file.secondIndex[i][j].ID);

			fread(&vi, sizeof(int), 1, fp);
			printf("num: %d(%d)\n", vi, i_file.secondIndex[i][j].num);

			fread(pi, sizeof(int), i_file.M, fp);
			for (k=0;k<i_file.M;k++)
			{
				printf("%d(%d)\t", pi[k], i_file.secondIndex[i][j].begin[k]);
			}
			printf("\n");

			fread(pi, sizeof(int), i_file.M, fp);
			for (k=0;k<i_file.M;k++)
			{
				printf("%d(%d)\t", pi[k], i_file.secondIndex[i][j].end[k]);
			}
			printf("\n");
		}
	}

	
	free(pi);
	fclose(fp);

	system("pause");
	return 0;
}
*/


/*
// check the .index files
int main()
{
	int		n				= 50;
	int		d				= 32;
	int		L				= 4;
	int		M				= 4;
	int		B				= 5;
	float	W				= 0.2;
	char	filename[40]	= "../Color/colorQ.txt";

	char	destFolder[40]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";

	// ---------- ���������ṹ ---------- //

	IndexFile i_file;
	i_file.initialize(n, d, L, M, B, W, filename);
	i_file.generateLSHFunctions();
	i_file.getHashKeys();
	i_file.sortHashKeys();
	i_file.buildIndex();

	// ---------- �������ṹд���ļ� ---------- //

	writeIndexToFiles(destFolder, &i_file);

	// ---------- ��д��ȥ���ļ�һһ��������У�����Ƿ����� ---------- //

	char	fn[100];
	char	para[40]			= "para";
	char	secondidx[40]		= "secondidx";
	char	firstidx[40]		= ".index";
	char	sourceFolder[40]	= "E:\\WORKING\\LSH-File\\Color\\HashTables";
	FILE*	fp					= NULL;

	int		i					= -1;
	int		j					= -1;
	int		k					= -1;

	int		vi					= -1;
	float	vf					= 0.0;
	char	num_str[40];

	float*	pf					= (float*) malloc(sizeof(float)*(i_file.d+1)*i_file.n);
	int*	pi					= (int*) malloc(sizeof(int)*i_file.M);

	for (i=0;i<i_file.L;i++)
	{
		strcpy(fn, sourceFolder);
		strcat(fn, "\\");
		itoa(i, num_str, 10);
		strcat(fn, num_str);
		strcat(fn, firstidx);

		fp = fopen(fn, "rb");

		if (NULL == fp)
		{
			printf("Fail to open %s.\n", fn);

			system("pause");
			return -1;
		}

		printf("Informaton for Table %d.\n", i);

		// ���first index
		//for (j=0;j<i_file.num_first;j++)
		//{
		//	printf("%d-th item:\n", j);

		//	fread(&vi, sizeof(int), 1, fp);
		//	printf("ID = %d(%d)\n", vi, i_file.firstIndex[i][j].ID);

		//	fread(&vi, sizeof(int), 1, fp);
		//	printf("num = %d(%d)\n", vi, i_file.firstIndex[i][j].num);

		//	fread(pi, sizeof(int), i_file.M, fp);

		//	for (k=0;k<i_file.M;k++)
		//	{
		//		printf("%d(%d)\t", pi[k], i_file.firstIndex[i][j].begin[k]);
		//	}
		//	printf("\n");

		//	fread(pi, sizeof(int), i_file.M, fp);

		//	for (k=0;k<i_file.M;k++)
		//	{
		//		printf("%d(%d)\t", pi[k], i_file.firstIndex[i][j].end[k]);
		//	}
		//	printf("\n");
		//}

		fseek(fp, i_file.num_first*(2+2*i_file.M)*sizeof(int), SEEK_SET);
		
		fread(pf, sizeof(float), i_file.n*(i_file.d+1), fp);printf("good");

		for (j=0;j<i_file.n;j++)
		{
			printf("%d\t%d(%d)-th point: \n", j, (int)pf[j*(i_file.d+1)], i_file.orderList[i][j]);

			for (k=0;k<i_file.d;k++)
			{
				printf("%f(%f)\t", pf[j*(i_file.d+1)+k+1], i_file.ds.pointArray[i_file.orderList[i][j]*d+k]);
			}

			printf("\n");
		}

		
		fclose(fp);
	}

	free(pf);
	free(pi);

	system("pause");
	return 0;
}
*/