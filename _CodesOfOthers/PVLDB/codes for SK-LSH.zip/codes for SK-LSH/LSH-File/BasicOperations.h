/*-------------------------------------------------------

- Some basic operations necessary for this projected are
- defined and implemented in this .h file and the 
- corresponding .cpp file.

- By Yingfan Liu - 
- 2013-03-31 -

-------------------------------------------------------*/


#ifndef BasicOperations_INCLUDED
#define BasicOperations_INCLUDED

// define the class for a data set
class DataSet
{
public:
	// variables
	int n;						// the number of points contained in this data set
	int d;						// the dimensionality
	float* pointArray;			// the array recording the coordinates for each point

	// ----functions----
	DataSet();
	~DataSet();
	void getParameters(int _n,int _d);
	int readDataSetFromFile(char* _filename);
};

typedef DataSet* DataSetPtr;



// ------ compute the distance between two points ------ //
double distance(float* _p1, float* _p2, int _d);






#endif
