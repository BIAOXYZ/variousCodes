/*--------------------------------------------------------------

- This file is created to implement the functions defined in 
- heap.h file.

- By Yingfan Liu-
- 2013-04-08 -

--------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "heap.h"

// >>>>>>>>>>>>>>>>>>>> -- the functions for PageEntry -- <<<<<<<<<<<<<<<<<<< //
PageEntry::PageEntry()
{
	direction	= -1;
	pid			= -1;
	score[0]	= -1;
	score[1]	= -1;
	tid			= -1;
}

PageEntry::PageEntry(int _tid, int _pid, int _direction, int _score1, int _score2)
{
	tid			= _tid;
	pid			= _pid;
	direction	= _direction;
	score[0]	= _score1;
	score[1]	= _score2;
}

PageEntry::~PageEntry()
{
	//
}

PageEntry& PageEntry::operator=(PageEntry& pep)
{

	direction	= pep.direction;
	pid			= pep.pid;
	score[0]	= pep.score[0];
	score[1]	= pep.score[1];
	tid			= pep.tid;

	return *this;
}

int PageEntry::operator>(PageEntry& pep)
{
	if (score[0] > pep.score[0])
	{
		return TRUE;
	}

	if (score[0] < pep.score[0])
	{
		return FALSE;
	}

	if (score[0] == pep.score[0])
	{
		if (score[1] < pep.score[1])
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}


// >>>>>>>>>>>>>>>>>>>> -- the functions for PEheap -- <<<<<<<<<<<<<<<<<<< //


PEheap::PEheap()
{
	this->num	= -1;
	this->maxN	= -1;
	this->heap	= NULL;
}

PEheap::~PEheap()
{
	this->num	= -1;
	this->maxN	= -1;

	if (this->heap)
		free(this->heap);
	this->heap	= NULL;
}

void PEheap::initialize(int _maxN)
{
	this->num = 0;

	if (_maxN <= 0)
	{
		printf("the max number of elements for a heap must exceed 0.\n");

		system("pause");
		exit(-1);
	}

	if (heap)
	{
		free(heap);
	}

	this->maxN = _maxN;

	this->heap = (PageEntry*) malloc(sizeof(PageEntry)*_maxN);

	if(NULL == this->heap)
	{
		printf("Fail to allocate enough memory space for REheap.heap.\n");

		system("pause");
		exit(-1);
	}
}

void PEheap::reset()
{
	num = 0;
}

// the insert operation for the heap of data pages
void PEheap::insert(PageEntry pe)
{
	PageEntry	 t_pe;
	int			 father = -1;
	int			 child  = -1;

	// if the heap is empty
	if (0 == num)
	{
		// add the new element to the head of the heap	
		heap[0]	= pe;	

		num++;
		return ;
	}

	if (num >= maxN)
	{
		printf("The page heap cannot hold any new element.\n");
		system("pause");
		exit(-1);
	}

	// add the new element to the heap
	heap[num] = pe;

	child					= num;
	father					= (int)ceil((float)child/2) - 1;

	while (father >= 0)
	{
		// if the score of the child is larger than its father,
		// exchange the child and its father
		if (heap[child] > heap[father])
		{
			t_pe			= heap[child];
			heap[child]		= heap[father];
			heap[father]	= t_pe;

			child			= father;
			father			= (int)ceil((float)child/2) - 1;
		}
		else
		{
			break;
		}
	}

	num++;
}

PageEntry PEheap::extract()
{
	if (0 == num)
	{
		printf("There are no element to extract in the heap of data page.\n");
		system("pause");
		exit(-1);
	}

	int left		= -1;
	int right		= -1;
	int current		= -1;
	int best		= -1;

	PageEntry ret;
	PageEntry t_pe;

	ret = heap[0];

	num--;

	if (0 == num)
	{
		return ret;
	}

	// put the last element in the heap to the head
	heap[0] = heap[num];

	current				= 0;
	left				= current * 2 + 1;
	right				= left + 1;

	while (left < num)
	{
		best = current;

		if (heap[left] > heap[current])
		{
			best = left;
		}
			
		if (right < num  &&  heap[right] > heap[best])
		{
			best = right;
		}

		if (best == current)
		{
			break;
		}

		else
		{
			// exchange the current and the best
			t_pe			= heap[best];
			heap[best]		= heap[current];
			heap[current]	= t_pe;
			
			current			= best;
			left			= current * 2 + 1;
			right			= left + 1;
		}	
	}

	return ret;
}


// >>>>>>>>>>>>>>>>>>>> -- the functions for ResultEntry -- <<<<<<<<<<<<<<<<<<< //

ResultEntry::ResultEntry()
{
	//dim				= -1;
	distance		= -1;
	pid				= -1;
	//coordinates		= NULL;
}

ResultEntry::ResultEntry(int _pid, double _distance)
{
	pid				= _pid;
	distance		= _distance;
	//dim				= -1;
	//coordinates		= NULL;
}

//ResultEntry::ResultEntry(int _dim)
//{
//	pid			= -1;
//	distance	= 0.0;
//	dim			= _dim;
//	coordinates = (float*) malloc(sizeof(float)*_dim);

//	int i = -1;
//	for (i=0;i<_dim;i++)
//	{
//		coordinates[i] = 0.0;
//	}
//}

//ResultEntry::ResultEntry(int _pid, double _distance, int _dim, float* _coordinates)
//{
//	pid				= _pid;
//	distance		= _distance;
//	dim				= _dim;
//	coordinates     = (float*) malloc(sizeof(float)*_dim);

//	int i = -1;

//	for (i=0;i<_dim;i++)
//	{
//		coordinates[i] = _coordinates[i];
//	}
//}

ResultEntry::~ResultEntry()
{
	pid				= -1;
	distance		= -1;
	//dim				= -1;

	//if (coordinates)
	//{
	//	free(coordinates);
	//}
}

//void ResultEntry::initialize(int _dim)
//{
//	coordinates = (float*) malloc(sizeof(float)*_dim);
//}

//void ResultEntry::reset(int _pid, double _distance, int _dim, float* _coordinates)
//{
//	pid				= _pid;
//	distance		= _distance;
//	dim				= _dim;

//	int i = -1;

//	for (i=0;i<_dim;i++)
//	{
//		coordinates[i] = _coordinates[i];
//	}
//}

ResultEntry& ResultEntry::operator=(ResultEntry& _re)
{
	pid				= _re.pid;
//	dim				= _re.dim;
	distance		= _re.distance;

//	int i = -1;

//	for (i=0;i<_re.dim;i++)
//	{
//		coordinates[i] = _re.coordinates[i];
//	}

	return *this;
}

int ResultEntry::operator>(ResultEntry& _re)
{
	if (distance > _re.distance)
		return TRUE;
	else
		return FALSE;
}

// >>>>>>>>>>>>>>>>>>>> -- the functions for REheap -- <<<<<<<<<<<<<<<<<<< //
REheap::REheap()
{
	num  = -1;
	maxN = -1;
	heap = NULL;
}

REheap::~REheap()
{
	num  = -1;
	maxN = -1;

	if (heap)
		free(heap);
	heap = NULL;
}

void REheap::initialize(int _maxN)
{
	num = 0;

	if (_maxN <= 0)
	{
		printf("The maximal number of elements in a re heap must exceed 0.\n");

		system("pause");
		exit(-1);
	}

	maxN = _maxN;

	heap = (ResultEntry*) malloc(sizeof(ResultEntry)*maxN);
	
	if(NULL == heap)
	{
		printf("Fail to allocate enough memory space for REheap.heap.\n");

		system("pause");
		exit(-1);
	}
}
void REheap::reset()
{
	num = 0;
}

void REheap::insert(ResultEntry& _re)
{
	ResultEntry	 t_re;
	int			 father = -1;
	int			 child  = -1;

	if (0 == num)
	{
		heap[0] = _re;
	}

	if (num >= maxN)
	{
		printf("The REheap has no more space for the new elements.\n");
		system("pause");
		exit(-1);
	}

	heap[num] = _re;

	child = num;
	father = (int) ceil((float)child/2) - 1;

	while (father >= 0)
	{
		if (heap[child] > heap[father])
		{
			t_re = heap[child];
			heap[child] = heap[father];
			heap[father] = t_re;

			child =father;
			father = (int) ceil((float)child/2) - 1;
		}
		else
		{
			break;
		}
	}

	num++;
}

ResultEntry REheap::extract()
{
	if (0 == num)
	{
		printf("There are no element to extract in the REheap.\n");
		system("pause");
		exit(-1);
	}

	int left		= -1;
	int right		= -1;
	int current		= -1;
	int best		= -1;

	ResultEntry ret;
	ResultEntry t_pe;

	ret = heap[0];

	num--;

	if (0 == num)
	{
		return ret;
	}

	// put the last element in the heap to the head
	heap[0] = heap[num];

	current				= 0;
	left				= current * 2 + 1;
	right				= left + 1;

	while (left < num)
	{
		best = current;

		if (heap[left] > heap[current])
		{
			best = left;
		}
			
		if (right < num  &&  heap[right] > heap[best])
		{
			best = right;
		}

		if (best == current)
		{
			break;
		}

		else
		{
			// exchange the current and the best
			t_pe			= heap[best];
			heap[best]		= heap[current];
			heap[current]	= t_pe;
			
			current			= best;
			left			= current * 2 + 1;
			right			= left + 1;
		}	
	}

	return ret;
}

void REheap::sort()
{
	int i = -1;
	int number = num;
	ResultEntry t_re;

	for (i=number;i>0;i--)
	{
		t_re = extract();
		heap[i-1] = t_re;
	}

	num = number;
}


double compareResult(REheap& _rh1, REheap& _rh2)
{
	double dist_ratio = 0.0;
	//ResultEntry re1, re2;
	int i = -1;
	
	_rh1.sort();
	_rh2.sort();

	for (i=0;i<_rh1.maxN;i++)
	{
		dist_ratio += _rh1.heap[i].distance / _rh2.heap[i].distance;
	}

	dist_ratio = dist_ratio / _rh1.maxN;

	return dist_ratio;
}


/*
ResultEntry& ResultEntry::operator=(ResultEntry& _re)
{
	distance = _re.distance;
	pid		 =  
}
*/



/*
// determine which PageEntry variable is larger
int isLarge_pe(PageEntryPtr pep1, PageEntryPtr pep2)
{
	if (pep1->score[0] > pep2->score[0])
	{
		return TRUE;
	}

	if (pep1->score[0] < pep2->score[0])
	{
		return FALSE;
	}

	if (pep1->score[0] == pep2->score[0])
	{
		if (pep1->score[1] < pep2->score[1])
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}


// the insert operation for the heap of data pages
void PEheap::insert(PageEntry pe)
{
	PageEntry	 t_pe;
	int			 father = -1;
	int			 child  = -1;

	// if the heap is empty
	if (0 == num)
	{
		// add the new element to the head of the heap	
		heap[0].direction	= pe.direction;
		heap[0].pid			= pe.pid;
		heap[0].score[0]	= pe.score[0];
		heap[0].score[1]	= pe.score[1];
		heap[0].tid			= pe.tid;
		
		num++;

		return ;
	}

	if (num >= maxN)
	{
		printf("The page heap cannot hold any new element.\n");
		system("pause");
		exit(-1);
	}

	// add the new element to the heap
	heap[num].direction		= pe.direction;
	heap[num].pid			= pe.pid;
	heap[num].score[0]		= pe.score[0];
	heap[num].score[1]		= pe.score[1];
	heap[num].tid			= pe.tid;

	child					= num;
	father					= (int)ceil((float)child/2) - 1;

	while (father >= 0)
	{
		// if the score of the child is larger than its father,
		// exchange the child and its father
		if (isLarge_pe(&heap[child], &heap[father]))
		{
			t_pe.direction				= heap[child].direction;
			t_pe.pid					= heap[child].pid;
			t_pe.score[0]				= heap[child].score[0];
			t_pe.score[1]				= heap[child].score[1];
			t_pe.tid					= heap[child].tid;

			heap[child].direction		= heap[father].direction;
			heap[child].pid				= heap[father].pid;
			heap[child].score[0]		= heap[father].score[0];
			heap[child].score[1]		= heap[father].score[1];
			heap[child].tid				= heap[father].tid;

			heap[father].direction		= t_pe.direction;
			heap[father].pid			= t_pe.pid;
			heap[father].score[0]		= t_pe.score[0];
			heap[father].score[1]		= t_pe.score[1];
			heap[father].tid			= t_pe.tid;

			child						= father;
			father						= (int)ceil((float)child/2) - 1;
		}
		else
		{
			break;
		}
	}


	num++;
}

PageEntry PEheap::extract()
{
	if (0 == num)
	{
		printf("There are no element to extract in the heap of data page.\n");
		system("pause");
		exit(-1);
	}

	int left		= -1;
	int right		= -1;
	int current		= -1;
	int best		= -1;
	PageEntry ret;
	PageEntry t_pe;

	ret.direction	= heap[0].direction;
	ret.pid			= heap[0].pid;
	ret.score[0]	= heap[0].score[0];
	ret.score[1]	= heap[0].score[1];
	ret.pid			= heap[0].pid;

	num--;

	if (0 == num)
	{
		return ret;
	}

	// put the last element in the heap to the head
	heap[0].direction	= heap[num].direction;
	heap[0].pid			= heap[num].pid;
	heap[0].score[0]	= heap[num].score[0];
	heap[0].score[1]	= heap[num].score[1];
	heap[0].tid			= heap[num].tid;

	current				= 0;
	left				= current * 2 + 1;
	right				= left + 1;

	while (left < num)
	{
		best = current;

		if (isLarge_pe(&heap[left], &heap[current]))
		{
			best = left;
		}
			
		if (right < num  &&  isLarge_pe(&heap[right], &heap[best]))
		{
			best = right;
		}

		if (best == current)
		{
			break;
		}

		else
		{
			// exchange the current and the best
			t_pe.direction				= heap[best].direction;
			t_pe.pid					= heap[best].pid;
			t_pe.score[0]				= heap[best].score[0];
			t_pe.score[1]				= heap[best].score[1];
			t_pe.tid					= heap[best].tid;

			heap[best].direction		= heap[current].direction;
			heap[best].pid				= heap[current].pid;
			heap[best].score[0]		= heap[current].score[0];
			heap[best].score[1]		= heap[current].score[1];
			heap[best].tid				= heap[current].tid;

			heap[current].direction		= t_pe.direction;
			heap[current].pid			= t_pe.pid;
			heap[current].score[0]		= t_pe.score[0];
			heap[current].score[1]		= t_pe.score[1];
			heap[current].tid			= t_pe.tid;
		}

		current				= best;
		left				= current * 2 + 1;
		right				= left + 1;
	}
}
*/










