/*--------------------------------------------------------------

- In this .h file, functions and classes necessary for the 
- search process are defined.

- By Yingfan Liu -
- 2013-04-08 -

--------------------------------------------------------------*/

#ifndef search_INCLUDED
#define search_INCLUDED


#include "construction.h"
#include "BasicOperations.h"
#include "heap.h"

#define TRUE	1
#define FALSE	0
#define LEFT	0 
#define RIGHT	1


// the class processing approximate knn search
class SearchClass
{
public:

	// ------ basic variables ------ //

	int			n;									// size of the data set
	int			d;									// the dimensionality
	int			L;									// number of hash files
	int			M;									// number of LSH functions contained in a file	
	int			B;									// size of a page (the number of points a page can contatin the most
	//int		nk;									// the number of returned points


	// - variables related to LSH functions -
	float*		a_array;							// the array for random vectors of LSH functions						
	float*		b_array;							// the array for random variables of LSH functions
	//float		W;									// the width for each function
	float*		w_array;							// the array for the width of lsh functions in a hash table

	int**		q_hash_keys;						// the hash keys of the query

	// - variables related to index files -
	int			num_first;							// the total number of first index items
	int			num_second;							// the total number of second index items
	int			item_per_page;						// the largest number of page items a page can hold
	PageItem**	firstIndex;							// first index 
	int*		left_ptr;							// the pointer to the left page item
	int*		right_ptr;							// the pointer to the right page item
	//PageItem**	secondIndex;					// second index 
	//int*		left_SI_ptr;						// the left pointer to the secondIndex
	//int*		right_SI_ptr;						// the right pointer to the secondIndex
	//int*		left_SI_id;							// the id of the left second index item
	//int*		right_SI_id;						// the id of the right second index item
	char		index_folder[100];					// the folder containing the index files

	FILE**		fp_array;							// the pointers to each data file

	// - variables related to page selection -
	//PageItem**	left_FI_page;					// the left page containing the page items (first index) for each table
	//PageItem**	right_FI_page;					// the right page containing the page items (first index) for each table
	//int*		left_FI_ptr;						// the left pointer related to left_FI_page
	//int*		right_FI_ptr;						// the right pointer related to left_FI_page
	//int*		left_FI_id;							// the id of the left page currently found for each table;
	//int*		right_FI_id;						// the id of the right page currently found for each table;

	// - variables - related to process the data page
	int*		point_accessed;						// whether the point is accessed
	int*		point_marked;						// point has been marked 
	int			npoint_marked;						// number of points marked

	float*		point_buffer;						// the buffer for a data page
	float**		point_array;						// the array of the points
	int*		id_array;							// the array of the ids
	//int			np_page;							// the number of points containing in this page

	// the page heap
	PEheap		page_heap;

	// the result heap
	//REheap		result_heap;

	// ------ functions ------ //
	SearchClass();
	~SearchClass();

	// read the parameters from the specified file
	//void readInfo(char* _filename);

	// read the secondidx from the responding file
	//void readSecondIndexFromFile();

	// the initialization for the search process
	void initialize(char* _foldername);

	// get the hash keys for a point
	void getPointHashKeys(float* _point);

	// find the best page item for a given array of page items
	// and the keys of the query
	void findOptimalItem(PageItem* _pi, int _npi, int* key, int* _left_ptr, int* _right_ptr);

	// load the first index to the memory according to 
	// given table id, page id
	//void loadFIpage(int _tid, int _pid, int _num, PageItem* _buffer);

	// determine whether the first score is better than the second on
	int isBetter_score(int* _s1, int* _s2);

	// determine whether the first key is larger then the second one
	int isLarge_key(int* _key1, int* _key2);

	// compute the score between two keys
	void computeScore(int* _key1, int* _key2, int* _score);

	// compute the score between the query and a data page
	void computeScore_page(int* _key, PageItem* _pi, int* _score);

	// initialize the left FI page and the right FI page for each table
	// according to the hash keys of the query
	//void initFiPage();

	// load a data page from the file according to given table and page id
	void loadDataPage(int _tid, int _pid, int _num);

	// the necessary process in the begining of the search process
	void necessary();

	void search(float* _query, int _nk, int _npage, REheap* _rh);
	
};





#endif