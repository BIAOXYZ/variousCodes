/*-----------------------------------------------------------------

- This file is created to define two kinds of heap class. 

- By Yingfan Liu -
- 2013-04-08 -

-----------------------------------------------------------------*/

#ifndef heap_INCLUDED
#define heap_INCLUDED

#define TRUE	1
#define FALSE	0
#define LEFT	0 
#define RIGHT	1


// >>>>>>>>>>>>>>>>>>> the heap for page selection <<<<<<<<<<<<<<<<<<<<

// the class indicating a data page
/*
struct PageEntry
{
	int tid;										// the id of the table 
	int pid;										// the id of the page
	int direction;									// the direction of the page relative to the very page
	int score[2];									// the score of this page

};
*/

class PageEntry
{
public:
	// --- variables
	int tid;										// the id of the table 
	int pid;										// the id of the page
	int direction;									// the direction of the page relative to the very page
	int score[2];									// the score of this page

	// --- functions ---
	PageEntry();
	PageEntry(int _tid, int _pid, int _direction, int _score1, int _score2);
	~PageEntry();

	PageEntry& operator=(PageEntry& pep);
	int operator>(PageEntry& pep);
};

typedef PageEntry*  PageEntryPtr;

// the class dealing with page selection using a heap structure
class PEheap
{
public:
	// --- variables --- //
	int num;										// the number of elements in this heap 
	int maxN;										// the maximal number of elements this heap can hold
	PageEntry* heap;								// the array containing elements

	// --- functions --- //
	PEheap();
	~PEheap();

	void initialize(int _maxN);
	void reset();
	void insert(PageEntry pe);
	PageEntry extract();
};

typedef PEheap* PEheapPtr;


// >>>>>>>>>>>>>>>>>>> the heap for results <<<<<<<<<<<<<<<<<<<<
class ResultEntry
{
public:
	// --- variables --- //
	int		pid;				// the id for the point
	//int		dim;				// the dimensionality of the point
	double	distance;			// the distance between the point and the query
	//float*	coordinates;		// the coordinates of the point

	// --- functions --- //
	ResultEntry();
	ResultEntry(int _pid, double _distance);
	//ResultEntry(int _dim);
	//ResultEntry(int _pid, double _distance, int _dim, float* _coordinates);
	~ResultEntry();

	//void initialize(int _dim);
	//void reset(int _pid, double _distance, int _dim, float* _coordinates);
	ResultEntry& operator=(ResultEntry& _re);
	int operator>(ResultEntry& _re);
};

typedef ResultEntry* ResultEntryPtr;

// the heap for Result Entry
class REheap
{
public:
	// --- variables --- //
	int num;
	int maxN;
	ResultEntry* heap;

	// --- functions --- //
	REheap();
	~REheap();

	void initialize(int _maxN);
	void reset();
	void insert(ResultEntry& _re);
	ResultEntry extract();
	void sort();
};


double compareResult(REheap& _rh1, REheap& _rh2);

#endif