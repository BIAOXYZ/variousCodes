/*---------------------------------------------------------

- This file implements the functions defined in construction.h.

- By Yingfan Liu -

- 2013-04-01 -

---------------------------------------------------------*/

#include "construction.h"
#include <math.h>
#include <time.h>
#include <direct.h>
#include <string.h>
#include "rand.h"

#define SUCCESS 1
#define FAILURE 0

IndexFile::IndexFile()
{
	n					= -1;
	d					= -1;
	L					= -1;
	M					= -1;
	B					= -1;

	a_array				= NULL;
	b_array				= NULL;
	//W					= -1;
	Wb					= 0.0;
	Wr					= 0.0;
	w_array				= NULL;

	hashKeyList			= NULL;
	orderList			= NULL;

	num_first			= -1;
	num_second			= -1;

	items_per_page		= -1;

	firstIndex			= NULL;
	secondIndex			= NULL;
}


void IndexFile::initialize(int _n, int _d, int _L, int _M, int _B, float _Wb, float _Wr, char* _filename)
{
	// set value for the parameters
	n = _n;
	d = _d;
	L = _L;
	M = _M;
	B = _B;

	// ----allocate memory for a_array and b_array
	a_array = (float*) malloc(sizeof(float)*L*M*d);
	if (NULL == a_array)
	{
		printf("Fail to allocate memory space for a_array.\n");
		system("pause");
		exit(-1);
	}
	b_array = (float*) malloc(sizeof(float)*L*M);
	if (NULL == b_array)
	{
		printf("Fail to allocate memory space for b_array.\n");
		system("pause");
		exit(-1);
	}
	//W = _W;
	Wb = _Wb;
	Wr = _Wr;
	w_array = (float*) malloc(sizeof(float)*M);
	if (NULL == w_array)
	{
		printf("Fail to allocate memory space for w_array.\n");
		system("pause");
		exit(-1);
	}

	// ---- get the data set from the data file
	ds.getParameters(n,d);
	ds.readDataSetFromFile(_filename);

	// ---- allocate memory space for hashKeyList and orderList ----
	// hashKeyList only contains the keys of a hash table
	// modified by Yingfan Liu, 2013-06-08
	hashKeyList = (int*) malloc(sizeof(int)*n*M);
	if (NULL == hashKeyList)
	{
		printf("Fail to allocate memory space for hashKeyList.\n");
		system("pause");
		exit(-1);
	}
	orderList   = (int*) malloc(sizeof(int)*n);
	if (NULL == orderList)
	{
		printf("Fail to allocate memory space for orderList.\n");
		system("pause");
		exit(-1);
	}

	int i = -1;
	int j = -1;

	// set the values related to the files 
	int pageSize		= B * (d+1);				// the number of coordinates a page can hold at most

	num_first			= (int) ceil( (float)n / (float)B );

	items_per_page		= (int) floor( (float)pageSize / (float)(2+2*M) );

	num_second			= (int) ceil( (float)num_first / (float)items_per_page );
	
	// firstIndex and secondIndex only contain the items in a single hash table
	// modified by Yingfan Liu 2013-06-08
	firstIndex	= (PageItem*) malloc(sizeof(PageItem)*num_first);

	if (NULL == firstIndex)
	{
		printf("Fail to allocate enough memory space for firstIndex.\n");
		system("pause");
		exit(-1);
	}

	for (j=0;j<num_first;j++)
	{
		firstIndex[j].begin = (int*) malloc(sizeof(int)*M);

		if (NULL == firstIndex[j].begin)
		{
			printf("Fail to allocate enough memory space for firstIndex[%d].begin.\n",j);
			system("pause");
			exit(-1);
		}

		firstIndex[j].end   = (int*) malloc(sizeof(int)*M);

		if (NULL == firstIndex[j].end)
		{
			printf("Fail to allocate enough memory space for firstIndex[%d].end.\n",j);
			system("pause");
			exit(-1);
		}
	}

	secondIndex	= (PageItem*) malloc(sizeof(PageItem)*num_second);

	if (NULL == secondIndex)
	{
		printf("Fail to allocate enough memory space for secondIndex.\n");
		system("pause");
		exit(-1);
	}

	for (j=0;j<num_second;j++)
	{
		secondIndex[j].begin = (int*) malloc(sizeof(int)*M);

		if (NULL == secondIndex[j].begin)
		{
			printf("Fail to allocate enough memory space for secondIndex[%d].begin.\n",j);
			system("pause");
			exit(-1);
		}

		secondIndex[j].end   = (int*) malloc(sizeof(int)*M);

		if (NULL == secondIndex[j].end)
		{
			printf("Fail to allocate enough memory space for secondIndex[%d].end.\n",j);
			system("pause");
			exit(-1);
		}
	}

}


IndexFile::~IndexFile()
{
	if (a_array)
	{
		free(a_array);
	}

	if (b_array)
	{
		free(b_array);
	}

	if (w_array)
	{
		free(w_array);
	}

	int i = -1;
	int j = -1;

	// haskKeyList, orderList, firstIndex and secondIndex only represent one single hash table
	// modified by Yingfan Liu 2013-06-08
	if (hashKeyList)
	{
		free(hashKeyList);
	}
	if (orderList)
	{
		free(orderList);
	}

	for (j=0;j<num_first;j++)
	{
		free(firstIndex[j].begin);
		free(firstIndex[j].end);
	}

	free(firstIndex);

	for (j=0;j<num_second;j++)
	{
		free(secondIndex[j].begin);
		free(secondIndex[j].end);
	}
		
	free(secondIndex);

}


void IndexFile::generateLSHFunctions()
{
	float mean = 0.0;
	float sigma = 1.0;
	float min = 0.0;
	float max;
	float w_last;

	int i = -1;
	int j = -1;
	int k = -1;

	// generate the array of the width
	w_last = Wb * Wr;
	for (i=0;i<M;i++)
	{
		w_array[i] = w_last / Wr;
		w_last	   = w_array[i];
	}

	// generate the seed of random variables
	srand((unsigned)time(NULL));

	for (i=0;i<L;i++)
	{
		for (j=0;j<M;j++)
		{
			for(k=0;k<d;k++)
			{
				a_array[i*M*d+j*d+k] = gaussian(mean, sigma);
			}

			max			   = w_array[j];
			b_array[i*M+j] = uniform(min, max);
		}
	}
}


void IndexFile::getHashKeys(int _tid)
{
	// judge whether _tid is a valid id of a hash table
	if (_tid < 0 || _tid >= L)
	{
		printf("_tid is not a legal id of a hash table.\n");
		system("pause");
		exit(-1);
	}

	int i = -1;
	int j = -1;
	int k = -1;
	int l = -1;

	double vf = 0.0;

	// hashKeyList and orderList only represent one single hash table
	// modified by Yingfan Liu on 2013-06-08

	i = _tid;
	// each point
	for (j=0;j<n;j++)
	{			
		// each LSH function
		for (k=0;k<M;k++)
		{
			vf = 0.0;
			for (l=0;l<d;l++)
			{
				vf += (double) ds.pointArray[j*d+l] * (double) a_array[i*M*d+k*d+l];
			}
			vf += b_array[i*M+k];
			hashKeyList[j*M+k] = (int) floor(vf / (double)w_array[k]);
		}
	}

	for (j=0;j<n;j++)
	{
		orderList[j] = j;
	}

}


// compare two keys K1 and K2 to determine whether K1 is larger than K2
int isLarge(int* K1, int* K2, int _m)
{
	int i = -1;
	for (i=0;i<_m;i++)
	{
		if (K1[i] > K2[i])
			return SUCCESS;
		
		if (K1[i] < K2[i])
			return FAILURE;
	}

	//return FAILURE;
	return SUCCESS;
}

// the partition function in the quick sort method
int partition(int _m, int* keys, int* orders, int p, int r)
{
	int  i = -1;
	int  j = -1;
	int  k = -1;
	int _x = -1;
	int _y = -1;

	int* x = (int*) malloc(sizeof(int)*_m);
	int* y = (int*) malloc(sizeof(int)*_m);

	// gives A[r] to a variable x
	for (i=0;i<_m;i++)
	{
		x[i] = keys[r*_m+i];
	}
	_x = orders[r];
	

	i = p - 1;
	for (j=p;j<r;j++)
	{
		// give A[j] to y
		for (k=0;k<_m;k++)
		{
			y[k] = keys[j*_m+k];
		}
		_y = orders[j];

		// is A[j] <= x
		if (!isLarge(y,x,_m))
		{
			i = i + 1;

			// exchange A[i] and A[j]
			for (k=0;k<_m;k++)
			{
				keys[j*_m+k] = keys[i*_m+k];
			}

			for (k=0;k<_m;k++)
			{
				keys[i*_m+k] = y[k];
			}
			
			orders[j] = orders[i];
			orders[i] = _y;
		}
	}

	// exchange A[i+1] and A[r]
	for (k=0;k<_m;k++)
	{
		keys[r*_m+k] = keys[(i+1)*_m+k];
	}

	for (k=0;k<_m;k++)
	{
		keys[(i+1)*_m+k] = x[k];
	}

	orders[r]   = orders[i+1];
	orders[i+1] = _x;

	free(x);
	free(y);

	return i+1;

}


// use the QUICKSORT algorithm to sort the hash keys and 
// obtain the responding orders
void quickSort(int _m, int* keys, int* orders, int p, int r)
{
	int q = -1;

	if (p < r)
	{
		q = partition(_m, keys, orders, p, r);
		quickSort(_m, keys, orders, p, q-1);
		quickSort(_m, keys, orders, q+1, r);
	}
}


// use the BubbleSORT algorithm to sort the hash keys and 
// obtain the responding orders
void bubbleSort(int _m, int* keys, int* orders, int _n)
{
	int i		= -1;
	int j		= -1;
	int k		= -1;
	int _x		= -1;
	int _y		= -1;

	int* x		= (int*) malloc(sizeof(int)*_m);
	int* y		= (int*) malloc(sizeof(int)*_m);

	for (i=_n-1;i>0;i--)
	{
		for (k=0;k<_m;k++)
		{
			// give the i-th(the last) key to x
			x[k] = keys[i*_m+k];			
		}
		_x	 = orders[i];

		for (j=0;j<i;j++)
		{
			// give the j-th key to y
			for (k=0;k<_m;k++)
			{
				y[k] = keys[j*_m+k];
			}
			_y = orders[j];

			// if y > x, exchange their value
			if (isLarge(y, x, _m))
			{
				for (k=0;k<_m;k++)
				{
					keys[j*_m+k] = x[k];
					x[k]		 = y[k];
					
				}

				orders[j] = _x;
				_x		  = _y;
			}
		}

		// give x to the i-th key
		for (k=0;k<_m;k++)
		{
			keys[i*_m+k] = x[k];
		}
		orders[i] = _x;
	}
}


void IndexFile::sortHashKeys()
{
	int i = -1;
	int p = 0;//
	int r = n - 1;//

	// hashKeyList and orderList only represent one single hash table
	// modified by Yingfan Liu on 2013-06-08

	quickSort(M, hashKeyList, orderList, p, r);
	//bubbleSort(M, hashKeyList, orderList, n);
}



void IndexFile::buildIndex(char* destFolder)
{
	// buildIndex also write the index structure into the corresponding files
	// modified by Yingfan Liu on 2013-06-08

	// check the existence of the folder
	if ( -1 == chdir(destFolder))
	{
		printf("Fail to find the folder %s. Please check!!\n", destFolder);
		system("pause");
		exit(-1);
	}

	char filename[100];
	char para[40]			= "para";
	char secondidx[40]		= "secondidx";
	char firstidx[40]		= ".index";
	FILE* fp				= NULL;

	int		i		= -1;
	int		j		= -1;
	int		k		= -1;
	int		b		= -1;
	int		e		= -1;
	int		_num	= -1;

	// generate the LSH functions
	generateLSHFunctions();

	// ------ write the parameters and lsh functions into the file ------  //
	// obtain the responding filename
	strcpy(filename, destFolder);
	strcat(filename, "\\");
	strcat(filename, para);

	fp = fopen(filename, "wb");

	if (NULL == fp)
	{
		printf("Fail to open %s.\n", filename);
		system("pause");
		exit(-1);
	}

	// basic parameters
	fwrite(&n, sizeof(int), 1, fp);
	fwrite(&d, sizeof(int), 1, fp);
	fwrite(&L, sizeof(int), 1, fp);
	fwrite(&M, sizeof(int), 1, fp);
	fwrite(&B, sizeof(int), 1, fp);	

	// write the lsh functions into the para file
	fwrite(a_array, sizeof(float), L*M*d, fp);
	fwrite(b_array, sizeof(float), L*M,   fp);
	fwrite(w_array, sizeof(float), M,     fp);

	fwrite(&num_first,      sizeof(int), 1, fp);
	fwrite(&num_second,     sizeof(int), 1, fp);
	fwrite(&items_per_page, sizeof(int), 1, fp);

	fclose(fp);


	// build and write L hash tables into the corresponding files
	for (i=0;i<L;i++)
	{
		// obtain the hash keys of i-th hash table
		getHashKeys(i);

		// sort the hash keys of i-th hash table
		sortHashKeys();

		// create the first index
		for (j=0;j<num_first;j++)
		{
			b = j * B;
			e = b + B -1;

			if (e > n-1)
			{
				e = n - 1;
			}

			_num = e - b + 1;

			firstIndex[j].ID  = j;
			firstIndex[j].num = _num;

			for (k=0;k<M;k++)
			{
				firstIndex[j].begin[k]  = hashKeyList[b*M+k];
				firstIndex[j].end[k]	= hashKeyList[e*M+k];
			}
		}

		// create the second index 
		for (j=0;j<num_second;j++)
		{
			b = j * items_per_page;
			e = b + items_per_page - 1;

			if (e > num_first-1)
			{
				e = num_first - 1;
			}

			_num = e - b + 1;

			secondIndex[j].ID  = j;
			secondIndex[j].num = _num;

			for (k=0;k<M;k++)
			{
				secondIndex[j].begin[k] = firstIndex[b].begin[k];
				secondIndex[j].end[k]   = firstIndex[e].end[k];
			}
		}

		// write the index structures into the corresponding files

		// ------ write the second index to the corresponding file ------ //
		// obtain the filename
		strcpy(filename, destFolder);
		strcat(filename, "\\");
		strcat(filename, secondidx);

		fp = fopen(filename, "ab+");

		if (NULL == fp)
		{
			printf("Fail to open %s.\n", filename);
			system("pause");
			exit(-1);
		}
		
		for (j=0;j<num_second;j++)
		{
			fwrite(&secondIndex[j].ID,   sizeof(int), 1, fp);
			fwrite(&secondIndex[j].num,  sizeof(int), 1, fp);

			fwrite(secondIndex[j].begin, sizeof(int), M, fp);
			fwrite(secondIndex[j].end,   sizeof(int), M, fp);
		}		

		fclose(fp);


		// ------ write the first index and the data set into the corrsponding file ------ //
		char	num_str[40];
		float*	pf = NULL;
		float	fv = 0.0;
	
		
		// obtain the file name
		strcpy(filename, destFolder);
		strcat(filename, "\\");
		itoa(i, num_str, 10);
		strcat(filename, num_str);
		strcat(filename, firstidx);

		fp = fopen(filename, "wb");

		if (NULL == fp)
		{
			printf("Fail to oper %s.\n", filename);
			system("pause");
			exit(-1);
		}

		// write the first index to the file
		for (j=0;j<num_first;j++)
		{
			fwrite(&firstIndex[j].ID,   sizeof(int), 1, fp);
			fwrite(&firstIndex[j].num,  sizeof(int), 1, fp);

			fwrite(firstIndex[j].begin, sizeof(int), M, fp);
			fwrite(firstIndex[j].end,   sizeof(int), M, fp);
		}

		// write the data set to the file
		for (j=0;j<n;j++)
		{
			// write the id of the point
			k  = orderList[j];
			fv = (float) k;
			fwrite(&fv, sizeof(float), 1, fp);

			// acquire the pointer referring to the starting place of the jth point
			pf = ds.pointArray + k*d;
			fwrite(pf, sizeof(float), d, fp);
			pf = NULL;
		}

		fclose(fp);
	}
}
