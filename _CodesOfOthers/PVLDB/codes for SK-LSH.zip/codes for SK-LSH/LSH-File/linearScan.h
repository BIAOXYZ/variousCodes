/*-------------------------------------------------------------

- In this file, we define the function scanning linearly the
- entire data set to obtain the exact neighbors.

- By Yingfan Liu -
- 2013-04-13 -

-------------------------------------------------------------*/


#ifndef linearScan_INCLUDED
#define linearScan_INCLUDED


#include "BasicOperations.h"
#include "heap.h"

void getExactNearestNeighbors(float* _query, DataSet* _pds, int _nk, REheap* _rh);
void getExactNearestNeighbors(float* _query, DataSet* _pds, int _nk, REheap& _rh);

// added by Yingfan Liu on 2013-06-08
void getGroundTruth(int _n, int _d, int _nq, char* _sourceFile, char* _queryFile, char* _resultFile);

#endif