/*------------------------------------------------------

- In this file, functions defined in responding .h file
- are implemented.

- By Yingfan Liu -
- 2013-04-08 -

------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <direct.h>
#include <string.h>
#include "search.h"
#include <math.h>


SearchClass::SearchClass()
{
	int i				= -1;
	int j				= -1;
	int k				= -1;

	// basic parameters
	n					= -1;
	d					= -1;
	L					= -1;
	M					= -1;
	B					= -1;
	//nk				= -1;

	// parameters related LSH functions
	a_array				= NULL;
	b_array				= NULL;
	//W					= -1;
	w_array				= NULL;

	q_hash_keys			= NULL;

	// variables related to index files
	num_first			= -1;
	num_second			= -1;
	item_per_page		= -1;
	firstIndex			= NULL;
	left_ptr			= NULL;
	right_ptr			= NULL;
	//secondIndex		= NULL;
	//left_SI_ptr		= NULL;
	//right_SI_ptr		= NULL;
	//left_SI_id		= NULL;
	//right_SI_id		= NULL;

	fp_array			= NULL;

	// variables related to page selection
	//left_FI_page		= NULL;
	//right_FI_page		= NULL;
	//left_FI_ptr		= NULL;
	//right_FI_ptr		= NULL;
	//left_FI_id		= NULL;
	//right_FI_id		= NULL;

	point_accessed		= NULL;
	point_marked		= NULL;
	npoint_marked		= -1;
	point_buffer		= NULL;

	point_array			= NULL;
	id_array			= NULL;
	//np_page				= -1;
}


SearchClass::~SearchClass()
{
	int i = -1;
	int j = -1;

	// free a_array and b_array
	free(a_array);
	free(b_array);
	free(w_array);

	for (i=0;i<L;i++)
	{
		free(q_hash_keys[i]);
	}
	free(q_hash_keys);

	// free the memory space for first index and second index
	for (i=0;i<L;i++)
	{
		for (j=0;j<num_first;j++)
		{
			free(firstIndex[i][j].begin);
			free(firstIndex[i][j].end);
		}
		free(firstIndex[i]);
	}
	free(firstIndex);

	free(left_ptr);
	free(right_ptr);

	// free the memory space for first index and second index
	//for (i=0;i<L;i++)
	//{
	//	for (j=0;j<num_second;j++)
	//	{
	//		free(secondIndex[i][j].begin);
	//		free(secondIndex[i][j].end);
	//	}
	//	free(secondIndex[i]);
	//}
	//free(secondIndex);

	//free(left_SI_ptr);
	//free(right_SI_ptr);
	//free(left_SI_id);
	//free(right_SI_id);

	for (i=0;i<L;i++)
	{
		fclose(fp_array[i]);
	}
	free(fp_array);

	// free the memory space for left_FI_page and right_FI_page
	//for (i=0;i<L;i++)
	//{
	//	for (j=0;j<item_per_page;j++)
	//	{
	//		free(left_FI_page[i][j].begin);
	//		free(left_FI_page[i][j].end);

	//		free(right_FI_page[i][j].begin);
	//		free(right_FI_page[i][j].end);
	//	}

	//	free(left_FI_page[i]);
	//	free(right_FI_page[i]);
	//}

	//free(left_FI_page);
	//free(right_FI_page);

	//free(left_FI_ptr);
	//free(right_FI_ptr);
	//free(left_FI_id);
	//free(right_FI_id);

	free(point_accessed);
	free(point_marked);
	free(point_buffer);

	for (i=0;i<B;i++)
	{
		free(point_array[i]);
	}
	free(point_array);
	free(id_array);
}

void SearchClass::initialize(char* _foldername)
{
	// check the existence of the folder
	if ( -1 == chdir(_foldername))
	{
		printf("Fail to find the folder %s. Please check!!\n", _foldername);
		system("pause");
		exit(-1);
	}

	char filename[100];
	char num_str[40];
	FILE* fp;
	int i = -1;
	int j = -1;
	int k = -1;

	strcpy(index_folder, _foldername);

	// contruct the file name of the parameter file
	strcpy(filename, _foldername);
	strcat(filename, "\\");
	strcat(filename, "para");

	// open the parameter file
	fp = fopen(filename, "rb");

	if (NULL == fp)
	{
		printf("Fail to open %s.\n", filename);

		system("pause");
		exit(-1);
	}

	// read the basic paramters
	fread(&n, sizeof(int), 1, fp);
	fread(&d, sizeof(int), 1, fp);
	fread(&L, sizeof(int), 1, fp);
	fread(&M, sizeof(int), 1, fp);
	fread(&B, sizeof(int), 1, fp);

	// allocate memory space for a_array, b_array and w_array
	a_array = (float*) malloc(sizeof(float)*L*M*d);
	b_array = (float*) malloc(sizeof(float)*L*M);
	w_array = (float*) malloc(sizeof(float)*M);

	//printf("good\n");

	// get a_array, b_array and W from the parameter file
	fread(a_array, sizeof(float), L*M*d, fp);
	fread(b_array, sizeof(float), L*M, fp);
	//fread(&W, sizeof(W), 1, fp);
	fread(w_array, sizeof(float), M, fp);

	fread(&num_first, sizeof(int), 1, fp);
	fread(&num_second, sizeof(int), 1, fp);
	fread(&item_per_page, sizeof(int), 1, fp);

	fclose(fp);		// close the parameter file

	// allocate memory space for the q_hash_keys
	q_hash_keys = (int**) malloc(sizeof(int*)*L);
	for (i=0;i<L;i++)
	{
		q_hash_keys[i] = (int*) malloc(sizeof(int)*M);
	}

	// the file pointer array containing all the pointers to the data files
	fp_array = (FILE**) malloc(sizeof(FILE*)*L);
	for (i=0;i<L;i++)
	{
		strcpy(filename, _foldername);
		strcat(filename, "\\");
		itoa(i, num_str, 10);
		strcat(filename, num_str);
		strcat(filename, ".index");

		fp_array[i] = fopen(filename, "rb");
	}

	// allocate memory space for firstIndex
	firstIndex	= (PageItem**) malloc(sizeof(PageItem*)*L);

	for (i=0;i<L;i++)
	{
		firstIndex[i]	= (PageItem*) malloc(sizeof(PageItem)*num_first);

		for (j=0;j<num_first;j++)
		{
			firstIndex[i][j].begin = (int*) malloc(sizeof(int)*M);
			firstIndex[i][j].end   = (int*) malloc(sizeof(int)*M);
		}
	}

	// load the first index
	for (i=0;i<L;i++)
	{
		for (j=0;j<num_first;j++)
		{
			fread(&firstIndex[i][j].ID,   sizeof(int), 1, fp_array[i]);
			fread(&firstIndex[i][j].num,  sizeof(int), 1, fp_array[i]);

			fread(firstIndex[i][j].begin, sizeof(int), M, fp_array[i]);
			fread(firstIndex[i][j].end,   sizeof(int), M, fp_array[i]);
		}
	}

	left_ptr	= (int*) malloc(sizeof(int)*L);
	right_ptr	= (int*) malloc(sizeof(int)*L);

	// allocate memory space for secondIndex
	//secondIndex	= (PageItem**) malloc(sizeof(PageItem*)*L);

	//for (i=0;i<L;i++)
	//{
	//	secondIndex[i]	= (PageItem*) malloc(sizeof(PageItem)*num_second);

	//	for (j=0;j<num_second;j++)
	//	{
	//		secondIndex[i][j].begin = (int*) malloc(sizeof(int)*M);
	//		secondIndex[i][j].end   = (int*) malloc(sizeof(int)*M);
	//	}
	//}

	// load the second index
	//strcpy(filename, _foldername);
	//strcat(filename, "\\");
	//strcat(filename, "secondidx");

	// open the file containing the second index
	//fp = fopen(filename, "rb");

	//if (NULL == fp)
	//{
	//	printf("Fail to open %s.\n", filename);

	//	system("pause");
	//	exit(-1);
	//}

	// get each page item of the second index
	//for (i=0;i<L;i++)
	//{
	//	for (j=0;j<num_second;j++)
	//	{
	//		fread(&secondIndex[i][j].ID,   sizeof(int), 1, fp);
	//		fread(&secondIndex[i][j].num,  sizeof(int), 1, fp);

	//		fread(secondIndex[i][j].begin, sizeof(int), M, fp);
	//		fread(secondIndex[i][j].end,   sizeof(int), M, fp);
	//	}
	//}

	//fclose(fp);				// close the second index file

	//left_SI_ptr		= (int*) malloc(sizeof(int)*L);
	//right_SI_ptr	= (int*) malloc(sizeof(int)*L);

	//left_SI_id		= (int*) malloc(sizeof(int)*L);
	//right_SI_id		= (int*) malloc(sizeof(int)*L);

	

	// allocate memory space for variables related to page selection
	//left_FI_page  = (PageItem**) malloc(sizeof(PageItem*)*L);
	//right_FI_page = (PageItem**) malloc(sizeof(PageItem*)*L);

	//for (i=0;i<L;i++)
	//{
	//	left_FI_page[i]  = (PageItem*) malloc(sizeof(PageItem)*item_per_page);
	//	right_FI_page[i] = (PageItem*) malloc(sizeof(PageItem)*item_per_page);

	//	for (j=0;j<item_per_page;j++)
	//	{
	//		left_FI_page[i][j].begin  = (int*) malloc(sizeof(int)*M);
	//		left_FI_page[i][j].end    = (int*) malloc(sizeof(int)*M);

	//		right_FI_page[i][j].begin = (int*) malloc(sizeof(int)*M);
	//		right_FI_page[i][j].end   = (int*) malloc(sizeof(int)*M);
	
	//	}
	//}

	//left_FI_ptr		= (int*) malloc(sizeof(int)*L);
	//right_FI_ptr	= (int*) malloc(sizeof(int)*L);

	//left_FI_id		= (int*) malloc(sizeof(int)*L);
	//right_FI_id		= (int*) malloc(sizeof(int)*L);

	point_accessed	= (int*) malloc(sizeof(int)*n);
	point_marked	= (int*) malloc(sizeof(int)*n);
	npoint_marked	= 0;

	for (i=0;i<n;i++)
	{
		point_accessed[i] = FALSE;
	}

	point_buffer	= (float*) malloc(sizeof(float)*B*(d+1));
	point_array		= (float**) malloc(sizeof(float*)*B);

	for (i=0;i<B;i++)
	{
		point_array[i] = (float*) malloc(sizeof(float)*d);
	}

	id_array		= (int*) malloc(sizeof(int)*B);

	// the initialization of the page heap
	page_heap.initialize(2*L);
}

void SearchClass::getPointHashKeys(float* _point)
{
	int	i			= -1;
	int j			= -1;
	int k			= -1;
	double ret		= 0.0;

	for (i=0;i<L;i++)
	{
		for (j=0;j<M;j++)
		{
			ret = 0.0;

			for (k=0;k<d;k++)
			{
				ret += (double)_point[k] * (double)a_array[i*M*d+j*d+k];
			}

			ret += b_array[i*M+j];
			//q_hash_keys[i][j] = (int) floor(ret/(double)W);
			q_hash_keys[i][j] = (int) floor(ret/(double)w_array[j]);
		}
	}
}

// determine whether the first key is larger than the second on
int SearchClass::isLarge_key(int* _key1, int* _key2)
{
	int i = -1;
	for (i=0;i<M;i++)
	{
		if (_key1[i] > _key2[i])
			return TRUE;
		if (_key1[i] < _key2[i])
			return FALSE;
	}
	return FALSE;
}

void SearchClass::computeScore(int* _key1, int* _key2, int* _score)
{
	int	i		= -1;
	_score[0]	= 0;
	_score[1]	= 0;
	for (i=0;i<M;i++)
	{
		if (_key1[i] == _key2[i])
			_score[0]++;
		else
		{
			_score[1] = abs(_key1[i] - _key2[i]);
			break;
		}
	}

}

void SearchClass::computeScore_page(int* _key, PageItem* _pi, int* _score)
{
	if (!isLarge_key(_key, _pi->begin))
	{
		computeScore(_key, _pi->begin, _score);
		return;
	}
	else
	{
		if (!isLarge_key(_key, _pi->end))
		{
			_score[0] = M;
			_score[1] = 0;
		}
		else
		{
			computeScore(_key, _pi->end, _score);
		}
	}
}

int SearchClass::isBetter_score(int* _s1, int* _s2)
{
	if (_s1[0] > _s2[0])
	{
		return TRUE;
	}
	else if (_s1[0] == _s2[0])
	{
		if (_s1[1] < _s2[1])
		{
			return TRUE;
		}
	}

	return FALSE;
}

void SearchClass::findOptimalItem(PageItem* _pi, int _npi, int* _key, int* _left_ptr, int* _right_ptr)
{
	//int i		= -1;
	//int j		= -1;
	//int k		= -1;

	int left	= -1;
	int right	= -1;
	int middle	= -1;
	int idx		= -1;

	int score1[2];
	int score2[2];
	int idx1	= -1;
	int idx2	= -1;

	left	= 0;
	right	= 2*_npi - 1;
	middle	= (int) floor((float)(left + right) / 2);

	while (right - left > 1)
	{
		idx = (int) ((float)middle / 2);

		if (0 == middle%2)
		{
			// indicate the idx.begin key
			if (isLarge_key(_key, _pi[idx].begin))
			{
				left  = middle;
			}
			else
			{
				right = middle;
			}
		}
		else
		{
			// indicate the idx.end key
			if (isLarge_key(_key, _pi[idx].end))
			{
				left  = middle;
			}
			else
			{
				right = middle;
			}
		}

		middle	= (int) floor((float)(left + right) / 2);
	}

	if (right-left != 1)
	{
		printf("something is wrong!\n");
		system("pause");
		exit(-1);
	}

	if (0 == (left%2))
	{
		// left and right indicate the same page item
		idx = (int) ((float)left / 2);
		computeScore(_key, _pi[idx].begin, score1);
		computeScore(_key, _pi[idx].end,   score2);

		if (isBetter_score(score1, score2))
		{
			*_left_ptr  = idx - 1;
			*_right_ptr = idx;
		}
		else
		{
			*_left_ptr	= idx;
			*_right_ptr = idx + 1;
		}
	}
	else
	{
		*_left_ptr  = idx;
		*_right_ptr = idx + 1;
	}
}

void SearchClass::loadDataPage(int _tid, int _pid, int _num)
{
	if (_tid >= L || _tid<0 || _pid >= num_first || _pid < 0)
	{
		printf("Illegal data page access!!\n");
		system("pause");
		exit(-1);
	}

	int i	 = -1;
	int j	 = -1;
	FILE* fp = fp_array[_tid];

	long _offset = (2*M+2)*sizeof(int)*num_first + _pid*B*(d+1)*sizeof(float);
	fseek(fp, _offset, SEEK_SET);
	fread(point_buffer, sizeof(float), _num*(d+1), fp);

	for (i=0;i<_num;i++)
	{
		id_array[i] = (int)point_buffer[i*(d+1)];

		for (j=0;j<d;j++)
		{
			point_array[i][j] = point_buffer[i*(d+1)+1+j];
		}
	}
}

void SearchClass::necessary()
{
	int i = -1;

	if (npoint_marked > 0)
	{
		for (i=0;i<npoint_marked;i++)
		{
			point_accessed[point_marked[i]] = FALSE;
		}
	}

	npoint_marked = 0;

	// reset the page heap
	page_heap.reset();
}

void SearchClass::search(float* _query, int _nk, int _npage, REheap* _rh)
{
	int i = -1;
	int j = -1;
	int k = -1;
	int score[2];

	// execute some necessary processes
	necessary();

	// set the result heap
	//REheap result_heap;
	//_rh->initialize(_nk);
	_rh->reset();

	// get the hash keys of the query
	getPointHashKeys(_query);

	// find the optimal left data page and the right data page for each table
	// and push them into page heap
	for (i=0;i<L;i++)
	{
		findOptimalItem(firstIndex[i], num_first, q_hash_keys[i], &left_ptr[i], &right_ptr[i]);

		if (left_ptr[i] >= 0 && left_ptr[i] < num_first)
		{
			// compute the score between the key of the query and the data page
			computeScore_page(q_hash_keys[i], &firstIndex[i][left_ptr[i]], score);
			// push the page item into the page heap
			page_heap.insert(PageEntry(i, left_ptr[i], LEFT, score[0], score[1]));
		}

		if (right_ptr[i] >= 0 && right_ptr[i] < num_first)
		{
			// compute the score between the key of the query and the data page
			computeScore_page(q_hash_keys[i], &firstIndex[i][right_ptr[i]], score);
			// push the page item into the page heap
			page_heap.insert(PageEntry(i, right_ptr[i], RIGHT, score[0], score[1]));
		}
	}

	//printf("good\n");

	int npage_accessed	= 0;
	PageEntry page;
	int np_page			= -1;
	double dist			= 0.0;
	PageItem pi;

	while (npage_accessed < _npage)
	{
		// extract the page with the greatest score
		page = page_heap.extract();

		// load the corresponding page
		np_page	= firstIndex[page.tid][page.pid].num;
		loadDataPage(page.tid, page.pid, np_page);

		//printf("good\n");

		// compute the distance between the query and the points in the data page
		for (i=0;i<np_page;i++)
		{
			if (!point_accessed[id_array[i]])
			{
				dist = distance(_query, point_array[i], d);
				//temp_re.reset(id_array[i], dist, d, point_array[i]);
				//result_heap.insert(ResultEntry(id_array[i], dist, d, point_array[i]));
				// if the heap is not full, just insert the new point entry
				if (_rh->num < _nk)
				{
 					_rh->insert(ResultEntry(id_array[i], dist));
				}
				else
				{
					// if the heap is full
					// judge whether the operations are worthy
					if (dist < _rh->heap[0].distance)
					{
						// it is worthy, extracting the entry with the largest distance before inserting the new one
						_rh->extract();
						_rh->insert(ResultEntry(id_array[i], dist));
					}
				}

				point_accessed[id_array[i]] = TRUE;
				point_marked[npoint_marked] = id_array[i];
				npoint_marked++;
			}
		}

		//printf("good\n");

		// push the next page into the heap
		if (LEFT == page.direction)
		{
			// if the page is a left one
			left_ptr[page.tid]--;
			if (left_ptr[page.tid] >= 0)
			{
				// compute the score between the new left page and the query
				computeScore_page(q_hash_keys[page.tid], &firstIndex[page.tid][left_ptr[page.tid]], score);
				// insert the page item into the page heap
				page_heap.insert(PageEntry(page.tid, left_ptr[page.tid], LEFT, score[0], score[1]));
			}
		}
		else
		{
			// if the page is a right one
			right_ptr[page.tid]++;
			if (right_ptr[page.tid] < num_first)
			{
				// compute the score between the new left page and the query
				computeScore_page(q_hash_keys[page.tid], &firstIndex[page.tid][right_ptr[page.tid]], score);
				// insert the page item into the page heap
				page_heap.insert(PageEntry(page.tid, right_ptr[page.tid], RIGHT, score[0], score[1]));
			}
		}

		npage_accessed++;
	}
}


/*
void SearchClass::loadFIpage(int _tid, int _pid, int _num, PageItem* _buffer)
{
	if (_num < 1)
	{
		printf("the number of page item to be loaded must exceed 1.\n");
		system("pause");
		exit(-1);
	}

	if (_pid<0 || _pid>=num_first)
	{
		printf("This page id %d is out of the correct range.\n", _pid);
		system("pause");
		exit(-1);
	}

	int i = -1;
	int j = -1;
	int k = -1;

	int* stream_int	= (int*) malloc(sizeof(int)*(2+2*M)*_num);		// the buffer of the stream read from the file

	fseek(fp_array[_tid], sizeof(int)*(2+2*M)*item_per_page*_pid, SEEK_SET);

	fread(stream_int, sizeof(int), (2+2*M)*_num, fp_array[_tid]);

	for (i=0;i<_num;i++)
	{
		_buffer[i].ID  = stream_int[i*(2+2*M)];
		_buffer[i].num = stream_int[i*(2+2*M)+1];

		for (j=0;j<M;j++)
		{
			_buffer[i].begin[j] = stream_int[i*(2+2*M)+2+j];
			_buffer[i].end[j]	= stream_int[i*(2+2*M)+2+M+j];
		}
	}

	free(stream_int);
}
*/


/*
void SearchClass::initFiPage()
{
	int i		= -1;
	int j		= -1;
	int k		= -1;

	for (i=0;i<L;i++)
	{
		findOptimalItem(secondIndex[i], num_second, q_hash_keys[i], &left_SI_ptr[i], &right_SI_ptr[i]);

		// if the left pointer is valid
		if (left_SI_ptr[i] >= 0)
		{
			// load the corresponding first index to the memory
			 
		}

		// if the right pointer if valid
		if (right_SI_ptr[i] < num_second)
		{

		}
	}
}
*/