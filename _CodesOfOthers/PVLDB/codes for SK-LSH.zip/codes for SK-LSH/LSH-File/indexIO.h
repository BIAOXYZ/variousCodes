/*---------------------------------------------------------------------

- This file copes with how to wrtie the whole index files to the disk
- pages and read all or part of the index files. 

- By Michael Liu -

- 2013-04-02 -

---------------------------------------------------------------------*/

#ifndef indexIO_INCLUDED
#define indexIO_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "construction.h"

// write the index files to the specified folder
void writeIndexToFiles(char* destFolder, IndexFilePtr idxfl);

// read the index files from the specified folder
// void readIndexFromFiles(char* sourceFolder, IndexFilePtr);

#endif