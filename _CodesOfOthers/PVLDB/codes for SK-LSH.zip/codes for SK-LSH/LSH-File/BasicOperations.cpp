#include "BasicOperations.h"
#include <stdio.h>
#include <iostream>


DataSet::DataSet()
{
	n = -1;
	d = -1;
	pointArray = NULL;
}


DataSet::~DataSet()
{
	delete pointArray;
}

void DataSet::getParameters(int _n,int _d)
{
	n = _n;
	d = _d;
}


int DataSet::readDataSetFromFile(char* _filename)
{
	// allocate memory space for pointArray
	pointArray = (float*) malloc(sizeof(float)*n*d);

	if (NULL == pointArray)
	{
		printf("Fail to allocate enough memory space for pointArray.\n");
		system("pause");
		exit(-1);
	}

	FILE* fp = fopen(_filename,"r");

	int    i = -1;
	int    j = -1;
	int   vi = -1;

	if (NULL == fp)
	{
		printf("Fail to open file %s.\n",_filename);
		system("pause");
		exit(-1);
	}

	for(i=0;i<n;i++)
	{
		if (feof(fp))
		{
			printf("there are less than %d points.\n",n);
			system("pause");
			fclose(fp);
			fp = NULL;
			exit(-1);
		}

		fscanf(fp,"%d",&vi);
		//printf("%d\n",vi);

		for(j=0;j<d;j++)
		{
			fscanf(fp,"%f",&pointArray[i*d+j]);
		}
	}

	fclose(fp);
	fp = NULL;

	return 0;
}





double distance(float* _p1, float* _p2, int _d)
{
	int    i = -1;
	double l = 0.0;

	for (i=0;i<_d;i++)
	{
		l += (double)(_p1[i] - _p2[i]) * (double)(_p1[i] - _p2[i]);
	}

	l = sqrt(l);

	return l;
}



/*
// ------ test the distance function ------ //

int main()
{
	float a[4] = {1, 2, 3, 4};
	float b[4] = {4, 3, 2, 1};

	double s = 0.0;

	s = distance(a, b, 4);

	printf("%lf\n", s);
	printf("%lf\n", s*s);

	system("pause");
	return 0;
}
*/