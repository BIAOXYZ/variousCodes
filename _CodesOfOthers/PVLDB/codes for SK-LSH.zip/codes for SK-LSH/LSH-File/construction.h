/*--------------------------------------------------------------------------

- This file contains functinos related to the construction of 
- the index file.
- By Yingfan Liu -
- 2013-04-01 -

--------------------------------------------------------------------------*/


#ifndef CONSTRUCTION_INCLUDED
#define CONSTRUCTION_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "BasicOperations.h"

struct PageItem
{
	int  ID;				// the ID of the item
	int  num;				// number of items a page can hold

	int* begin;				// the first item in the page
	int* end;				// the last item in the page
};

typedef PageItem* PageItemPtr;

class IndexFile
{
public:
	int			n;									// size of the data set
	int			d;									// the dimensionality
	int			L;									// number of hash files
	int			M;									// number of LSH functions contained in a file	
	int			B;									// size of a page (the number of points a page can contatin the most)

	// - variables related to LSH functions -
	float*		a_array;							// the array for random vectors of LSH functions						
	float*		b_array;							// the array for random variables of LSH functions
	//float		W;									// width of LSH functions
	float		Wb;
	float		Wr;
	float*		w_array;							// the array for each LSH functions in a hash table 

	// - variables related to hash keys -
	int *		hashKeyList;						// the array storing all hash keys for each points in each hash talbe
	int *		orderList;							// the array storing all orders for each point in each hash table

	// - varaibales related to the index files - 
	int			num_first;										// the number of first index items per file
	int			num_second;										// the number of second index items per file

	int			items_per_page;						// the number of items a page can hold the most

	PageItem*	firstIndex;							// the first index for all files
	PageItem*  secondIndex;						// the second index for all files

	//char		storeFolder[100];					// the folder where the whole index files are stored

	DataSet		ds;									// the data set

	// ------functinos------
	IndexFile();
	~IndexFile();

	void initialize(int _n, int _d, int _L, int _M, int _B, float _Wb, float _Wr, char* _filename);
	//void initialize(int _n, int _d, int _L, int _M, int _B, float _Wb, float _Wr, DataSet& _ds_ref);
													// the initialization of the class

	void generateLSHFunctions();					// generate the LSH functions for the class
	void getHashKeys(int _tid);								// calculate all the hash keys for each points in each hash table
	void sortHashKeys();							// sort the hash keys
	void buildIndex(char* destFolder);								// build the index structure

};


typedef IndexFile* IndexFilePtr;




#endif