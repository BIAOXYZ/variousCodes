/*------------------------------------------------------------

- In this file, we implement the functions defined in 
- linearScan.h.

- By Yingfan Liu -
- 2013-04-13 -

------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "linearScan.h"


void getExactNearestNeighbors(float* _query, DataSet* _pds, int _nk, REheap* _rh)
{
	int i			= -1;
	int j			= -1;
	double dist		= 0.0;
	float* point	= (float*) malloc(sizeof(float)*_pds->d);

	_rh->reset();

	for (i=0;i<_pds->n;i++)
	{
		for (j=0;j<_pds->d;j++)
		{
			point[j] = _pds->pointArray[i*_pds->d+j];
		}

		dist = distance(point, _query, _pds->d);

		if (_rh->num < _nk)
		{
			_rh->insert(ResultEntry(i, dist));
		}
		else
		{
			if (dist < _rh->heap[0].distance)
			{
				_rh->extract();
				_rh->insert(ResultEntry(i, dist));
			}
		}
	}

	//printf("%d\n", _rh->num);

	free(point);
}

void getExactNearestNeighbors(float* _query, DataSet* _pds, int _nk, REheap& _rh)
{
	int i			= -1;
	int j			= -1;
	double dist		= 0.0;
	float* point	= (float*) malloc(sizeof(float)*_pds->d);

	_rh.reset();

	for (i=0;i<_pds->n;i++)
	{
		for (j=0;j<_pds->d;j++)
		{
			point[j] = _pds->pointArray[i*_pds->d+j];
		}

		dist = distance(point, _query, _pds->d);

		if (_rh.num < _nk)
		{
			_rh.insert(ResultEntry(i, dist));
		}
		else
		{
			if (dist < _rh.heap[0].distance)
			{
				_rh.extract();
				_rh.insert(ResultEntry(i, dist));
			}
		}
	}

	//printf("%d\n", _rh->num);

	free(point);
}


// added by Yingfan Liu on 2013-06-08
void getGroundTruth(int _n, int _d, int _nq, char* _sourceFile, char* _queryFile, char* _resultFile)
{
	// ****** --- get the data sets --- ****** //
	DataSet ods, qds;
	ods.getParameters(_n, _d);
	ods.readDataSetFromFile(_sourceFile);
	qds.getParameters(_nq, _d);
	qds.readDataSetFromFile(_queryFile);

	int	i				= -1;
	int j				= -1;
	int k				= -1;

	float* query		= (float*)	malloc(sizeof(float)*_d);
	FILE* fp			= fopen(_resultFile, "w");

	int nk = 100;

	// write nq and nk into the result file
	fprintf(fp, "%d %d\n", _nq, nk);

	for (i=0;i<_nq;i++)
	{
		printf("i=%d\n",i);

		REheap rh;
		rh.initialize(nk);

		// get the query point
		for (j=0;j<_d;j++)
		{
			query[j] = qds.pointArray[i*_d+j];
		}

		getExactNearestNeighbors(query, &ods, nk, &rh);
		rh.sort();

		fprintf(fp, "%d ", i);		

		for (k=0;k<nk;k++)
		{
			fprintf(fp, "%f ", rh.heap[k].distance);
		}
			
		fprintf(fp, "\n");
	}


	fclose(fp);
}